﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SeApiClientService.Models;

namespace SeApiClientService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class GitApiController : ControllerBase
    {
       
        private readonly ILogger<GitApiController> _logger;
        public GitApiController(ILogger<GitApiController> logger)
        {
            _logger = logger;
        }

        private static readonly HttpClient client = new HttpClient();
        [HttpGet]
        public async Task<List<Repository>> Get()
        {
            // following line of code coud be written in a sperate block of code/file
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/vnd.github.v3+json"));
            client.DefaultRequestHeaders.Add("User-Agent", ".NET Foundation Repository Reporter");
            var gitQueryResult = "https://api.github.com/repositories?query=language:python&stars:>1000&sort=stars&order=desc&per_page=5";

            //could check the result status if its a bad request or not found
            var streamTask = client.GetStreamAsync(gitQueryResult);
            var repositories = await JsonSerializer.DeserializeAsync<List<Repository>>(await streamTask);
            // just returning a sort list
            return repositories;//.Take(5).ToList();
        }

        [HttpGet("{language}")]
        public async Task<List<Repository>>Get(string _language)
        {
           
                // following line of code coud be written in a sperate block of code/file
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/vnd.github.v3+json"));
                    client.DefaultRequestHeaders.Add("User-Agent", ".NET Foundation Repository Reporter");
                    var gitQueryResult = "https://api.github.com/repositories?query=language:python&sort=stars&order=desc&per_page=5";
                //could check the result status if its a bad request or not found
                var streamTask = client.GetStreamAsync(gitQueryResult);
                var repositories = await JsonSerializer.DeserializeAsync<List<Repository>>(await streamTask);

               return repositories;

        }
    }
}
